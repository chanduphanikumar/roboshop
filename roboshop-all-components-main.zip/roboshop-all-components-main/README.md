# RoboShop Project Setup 

In this project we are going to have total 11 components. 

1 - FRONTEND (UI)

6 - BACKEND APPS (API)

4 - DB SERVICES 

List of all the components are 

1. Frontend 
2. MongoDB 
3. Catalogue 
4. Redis 
5. User 
6. Cart 
7. MySQL 
8. Shipping 
9. RabbitMQ 
10. Payment 
11. Dispatch

*Note:* Those components need to setup in the same order for the application to work initially.

Project Diagram

![RoboShop Project EC2](diags/roboshop.jpg)

## 1. Frontend Setup 



